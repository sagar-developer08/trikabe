# user-mangement-api
# To run the application 
npm start (make sure nodemon should install in project)

#migartion will done once app start on the server using script in package.json*

# test.env is uploaded in server so to test the code 

Database :MonogoDb

Logs : winston

routes has end point of application entry point is server.js 

essentinal file is app.js

config file has all configrations once done in server
